package handling;

/**
 *
 * @author Emy
 */
public interface MapleServerHandlerMBean {

    public void writeLog();
}
