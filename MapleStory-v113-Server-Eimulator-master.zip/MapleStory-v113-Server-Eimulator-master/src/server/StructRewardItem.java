package server;

public class StructRewardItem {

    public int itemid;
    public long period;
    public short prob, quantity;
    public String effect, worldmsg;
}
