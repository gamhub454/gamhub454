package server;

/**
 *
 * @author RM
 */
public interface ShutdownServerMBean extends Runnable {

    public void shutdown();
}
