package server.maps;

public enum SpeedRunType {

    NULL,
    Horntail,
    ChaosHT,
    Papulatus,
    Nameless_Magic_Monster,
    Vergamot,
    Dunas,
    Nibergen,
    Dunas_2,
    Core_Blaze,
    Aufhaven,
    Scarlion,
    Targa,
    Pink_Bean,
    Zakum,
    Chaos_Zakum;
}
